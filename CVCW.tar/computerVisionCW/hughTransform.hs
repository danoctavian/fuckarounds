-- probabilistic labelling

--we make the assumption there are only 2 labels, therefore we store only the probability that it is an edge
--{-# LANGUAGE RankNTypes #-} -- Rank2Types is a synonym for RankNTypes
import Data.Array.IArray
import Data.Maybe
import Data.Array (listArray)
import System.Environment

data Pixel = Pixel Float [Int]
  deriving Show
data Label = E | NE
type Comp = Label -> Label -> Float

--let a = array (1,100) ((1,1) : [(i, i * a!(i-1)) | i \<- [2..100]])
--type Pixels = IArray Array Pixel
type Pixels = Array Int Pixel

doSteps :: Pixels -> Comp -> Int -> Pixels
doSteps pixs comp n = foldl (\pixs step -> step pixs) pixs (take n $ repeat (stepProbLabelling comp))

stepProbLabelling :: Comp -> Pixels -> Pixels
stepProbLabelling  comp pixels
  = fmap (\pix@(Pixel _ neighbors) ->  Pixel (edgeProbability pixels comp pix) neighbors) pixels

edgeProbability :: Pixels -> Comp -> Pixel -> Float
edgeProbability pixs comp pix
  = suppTimesProb E / (suppTimesProb E + suppTimesProb NE)
    where
      suppTimesProb :: Label -> Float
      suppTimesProb label = labelProb pix label * totalContextSupport pixs comp pix label

totalContextSupport :: Pixels -> Comp -> Pixel -> Label -> Float 
totalContextSupport pixs comp pix@(Pixel p neighbors) label
  = foldl (+) 0 (map (\neigh-> contextSupp pix label (pixs ! neigh) comp) neighbors)

contextSupp :: Pixel -> Label -> Pixel -> Comp -> Float
contextSupp pix label otherPix comp = partialSupp E + partialSupp NE
  where
    partialSupp :: Label -> Float
    partialSupp label2 = (comp label label2) * (labelProb otherPix label2)
      

labelProb :: Pixel -> Label -> Float
labelProb (Pixel p _) E = p
labelProb (Pixel p _) NE = 1 - p


-- elem width height
-- neighbor index for a matrix with 
neighbors :: Int-> Int -> Int ->  [Int]
neighbors i w h = (if' (i >= w) [i - w] [])  ++ (if' (i < w * (h - 2)) [i + w] []) ++ 
                  (if' (i `mod` w /= 0) [i - 1] []) ++ (if' (i `mod` w /= w - 1) [i + 1] [])

getPixelProbArray :: String ->  Pixels
getPixelProbArray str
 = Data.Array.listArray (0, w * h - 1) $ map (\(i, p) -> Pixel p (neighbors i w h)) (zip [0..w * h - 1] probs)
  where
    nums :: [Float]
    nums = map read $ words str
    [w, h] = map round (take 2 nums)
    probs = drop 2 nums
                  
if' :: Bool -> a -> a -> a
if' True left _ = left
if' False _ right = right

compA :: Label -> Label -> Float
compA _ _ = 1

compB :: Label -> Label -> Float
compB E E = 2
compB _ _ = 1



main :: IO ()
main = do
   args <- getArgs
   content <- readFile (args !! 0)
   arr <- return $ doSteps (getPixelProbArray content) (if' ((args !! 1) == "A") compA compB) 2
   putStrLn $ show arr
